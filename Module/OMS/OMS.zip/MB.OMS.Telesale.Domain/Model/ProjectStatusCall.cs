﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MB.OMS.Telesale.Domain.Model
{
    public class ProjectStatusCall
    {
        public int ProjectID { get; set; }
        public int StatusCallID { get; set; }
    }
}
