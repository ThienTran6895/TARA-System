﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MB.OMS.Telesale.Domain.Model
{
    public class Status
    {
        public int StatusID { get; set; }
        public string Name { get; set; }
    }
}
